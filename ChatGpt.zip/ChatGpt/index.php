<?php 
 include 'vendor/autoload.php';
 use  Orhanerday\OpenAi\OpenAi;
 $output = "";
   if(isset($_POST['submit'])){
     $search = $_POST['search'];
     $open_ai = new OpenAi('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'); 
     $complete =  $open_ai->completion([
       'model'=>'text-davinci-003',
       'prompt'=>$search,
       'max_tokens'=>500 ,
       'temperature' => 0.9,
       'frequency_penalty' => 0,
      'presence_penalty' => 0.6,
     ]);
    
     $decode = json_decode($complete,true);
     $output = $decode["choices"][0]['text'];
   
   }


 

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form method="POST">
        <p><pre>
        <?php echo $output ?>
        </pre></p>
        <input type="text" name="search"> <br>
        <button name="submit">search</button>

    </form>
</body>
</html>
